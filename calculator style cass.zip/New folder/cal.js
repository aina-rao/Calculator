var i = 0;

function getnumber(num) {
    var z = document.getElementById('input')
    switch (num) {
        case 1:
            z.value += '1';
            break;
        case 2:
            z.value += '2';
            break;
        case 3:
            z.value += '3';
            break;
        case 4:
            z.value += '4';
            break;
        case 5:
            z.value += '5';
            break;
        case 6:
            z.value += '6';
            break;
        case 7:
            z.value += '7';
            break;
        case 8:
            z.value += '8';
            break;
        case 9:
            z.value += '9';
            break;
        case 0:
            z.value += '0';
            break;
    }
}

function clearScr() {
    document.getElementById('input').value = "";
    document.getElementById('answer').value = "";

}

function getcomput() {
    var z = document.getElementById('input');
    ans = Math.floor(+eval(z.value));
    document.getElementById('answer').value = '=' + ans;
}

function getbracket() {
    var z = document.getElementById('input');
    if (i == 0) {
        z.value += '(';
        i = 1;
    } else if (i == 1) {
        z.value += ')';
        i = 0;
    }
}

function getOperand(op) {
    var z = document.getElementById('input');
    switch (op) {

        case '+':
            z.value += '+';
            break;
        case '-':
            z.value += '-';
            break;
        case '/':
            z.value += '/';
            break;
        case 'x':
            z.value += '*';
            break;
        case '+/-':
            z.value += '-' + z.value;
            break;
        case '.':
            z.value += '.';
            break;
    }
}

function backspace() {
    var z = document.getElementById('input');
    var x = z.value;
    if (x.length > 0) {
        x = x.substring(0, x.length - 1);
        z.value = x;
    }

}